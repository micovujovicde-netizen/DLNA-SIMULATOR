TERAPHON Receiver ANDROID v1.3 — PIN-authorized takeover

Separate app com.teraphon.receiver, Android 8+ (API 26), target 35.
Open once on receiving phone/tablet/Android TV; persistent foreground service
continues while UI is closed/minimized. EXIT shuts it down. STOP releases stream
and focus. Not configured to launch at system boot. App must be allowed to run
in background on the device. No root or accessibility permissions required.

Local 4-digit PIN is displayed/changed via PIN. Changing PIN revokes stored
pairing tokens. TLS identity generated and stored in Android Keystore per install.
SSDP + HTTP description on 49152, authenticated HTTPS controls on 49153.
One active audio source only. Another TERAPHON with the same 4-digit PIN, or
an already remembered valid pairing token, can TAKE OVER the Android Receiver.
Old source goes silent on the receiver, new source plays on the same Android
Bluetooth/system output. The first sender is NOT remotely stopped as an app;
its stream is detached from this receiver. No concurrent audio mixing.
Discovery, availability, PIN validation and pairing do NOT interrupt playback.
Takeover occurs only after the incoming sender has obtained capture consent and
sends an authenticated, valid SetAVTransportURI. This request must follow
explicit CONNECT (/status using a saved token, or /pair with the correct PIN)
within 3 minutes. The authorization is consumed at takeover, blocking the old
sender from taking control back via automatic retry. The same PIN works for
any authorized TERAPHON device. Unauthorized/bad PIN and
invalid PCM URL do not interrupt current music. Old owner's commands are
rejected with RECEIVER BUSY after takeover. Incomplete switch releases audio
focus after 30 seconds. Windows Receiver is NOT changed by this update.
Same PIN grants independent remote audio focus command. Pairing is rate-limited.
Sender compatibility: TERAPHON Android v0.2.200 secure receiver protocol:
L16 network-byte-order stereo, 44.1/48 kHz, same /pair, /status, /availability,
SOAP AVTransport, RenderingControl, /owner/pair, /owner/status, /owner/mute.

MUTE EXT PLAYERS on Android means requesting AUDIOFOCUS_GAIN; UNMUTE releases
focus. Wire replies MUTED/UNMUTED indicate focus state, NOT proof that every
external app has been muted. Some players do not respect focus, especially API
30 and below. On Android 12+ system forces fade-out under certain conditions.
Previous external app may need manual resume after focus release. Incoming
calls / loss of focus can stop receiver playback. No system master mute.

Build: upload project contents to a separate GitHub repository (not main
TERAPHON app). Workflow .github/workflows/android.yml, manual Run workflow.
Debug APK only, not a permanent release signature. Before public release set up
stable signing key; do not use ephemeral debug signing for future updates.

Verification: pure Java session gate takeover test passed locally; 12 routing contract checks passed. No Android SDK or
Gradle in this runtime: Android compile, TLS handshake, discovery, audio focus,
PCM playback and background behavior UNTESTED on device. Test before use.

Android v1.2: Broadcast _teraphon._tcp. mDNS via Android NsdManager on TCP port 49152. Existing SSDP discovery retained. No IP manual entry on TERAPHON sender v0.2.201; regular PIN pairing persists. Registration is stopped when receiver exits.

Android v1.3 HTTPS CONNECT REPAIR (22 November 2026):
- Select the existing RSA server key on Android SSLSocket and engine-backed TLS paths.
- TLS 1.3 + 1.2 negotiation where supported (TLS 1.2 fallback).
- Self-test PINNED HTTPS GET /availability on loopback after boot; displays HTTPS ERROR
  instead of a misleading READY when HTTPS fails. Self-test never uses PIN or token.
- HTTPS request exceptions appear in Receiver UI/status and Android logcat,
  without recording PINs, bearer tokens, or request bodies.
- Existing AndroidKeystore certificate alias, stored tokens, PIN, Bluetooth output,
  session takeover, SSDP and mDNS remain unchanged. Windows EXE untouched.
- This is source-level/static verification only; an on-device handshake, PIN and
  real audio playback must be confirmed before claiming a full fix.
