#!/usr/bin/env python3
from pathlib import Path
s=(Path(__file__).parents[1]/'app/src/main/java/com/teraphon/receiver/ReceiverService.java').read_text()
checks={
 "engine TLS can select AndroidKeystore RSA server alias": 'chooseEngineServerAlias' in s and 'rsa(t)?alias:null' in s,
 "socket TLS still selects server alias": 'chooseServerAlias(String t,Principal[] p,Socket s)' in s,
 "existing keystore alias is preserved": 'String alias="tera_receiver_tls"' in s,
 "pinned TLS self-test runs after accept": 'listeners.execute(()->accept(tls,true));listeners.execute(this::ssdp);listeners.execute(this::checkTls)' in s,
 "self-test does not pair with PIN": 'https://127.0.0.1:49153/availability' in s,
 "TLS failed probe has visible state": 'stage="HTTPS ERROR"' in s,
 "request failure is visible": 'lastError="HTTPS request: "' in s,
 "TLS 1.2 remains permitted": '"TLSv1.3","TLSv1.2"' in s,
 "no stored PIN broadcast in discovery": 'info.setAttribute("pin"' not in s,
}
for label,valid in checks.items():
 assert valid,label
print(f'HTTPS compatibility: {len(checks)} static checks passed')
