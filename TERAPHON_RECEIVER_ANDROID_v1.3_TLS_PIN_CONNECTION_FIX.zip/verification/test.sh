#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
D=$(mktemp -d)
trap 'rm -rf "$D"' EXIT
javac -d "$D" app/src/main/java/com/teraphon/receiver/SessionGate.java verification/SessionGateTest.java
java -cp "$D" com.teraphon.receiver.SessionGateTest
python3 verification/protocol_contract_test.py
python3 verification/nsd_contract_test.py

python3 verification/https_contract_test.py
