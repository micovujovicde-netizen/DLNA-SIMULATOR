package com.teraphon.receiver;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.widget.*;import android.view.*;import android.text.InputType;
public class MainActivity extends Activity {
 final Handler h=new Handler(Looper.getMainLooper()); TextView status; Button play,mute; SeekBar volume; boolean updating;
 @Override public void onCreate(Bundle b){super.onCreate(b); if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},1);
 startForegroundService(new Intent(this,ReceiverService.class)); LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setGravity(Gravity.CENTER);root.setPadding(22,22,22,22);root.setBackgroundColor(Color.BLACK);ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(Color.BLACK);scroll.addView(root);setContentView(scroll);
 ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.logo);logo.setAdjustViewBounds(true);root.addView(logo,new LinearLayout.LayoutParams(-1,dp(88))); TextView sub=text("Receiver",23);root.addView(sub);status=text("STARTING",16);status.setGravity(Gravity.CENTER);status.setVerticalScrollBarEnabled(true);status.setMovementMethod(new android.text.method.ScrollingMovementMethod());root.addView(status,new LinearLayout.LayoutParams(-1,dp(176)));
 LinearLayout row=new LinearLayout(this);play=button("▶ PLAY",()->{if(ReceiverService.instance!=null)ReceiverService.instance.toggle();});row.addView(play,new LinearLayout.LayoutParams(0,dp(60),1));row.addView(button("STOP",()->{if(ReceiverService.instance!=null)ReceiverService.instance.stopPlayback();}),new LinearLayout.LayoutParams(0,dp(60),1));root.addView(row,new LinearLayout.LayoutParams(-1,-2));
 mute=button("| MUTE |",()->{
   ReceiverService service=ReceiverService.instance;
   if(service!=null) updateMuteButton(service.toggleMute());
 });
 root.addView(mute,new LinearLayout.LayoutParams(-1,dp(54)));
 root.addView(text("VOLUME",14));volume=new SeekBar(this);volume.setMax(100);volume.setProgress(80);root.addView(volume,new LinearLayout.LayoutParams(-1,dp(56)));volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}public void onProgressChanged(SeekBar s,int n,boolean user){if(user&&ReceiverService.instance!=null)ReceiverService.instance.setVolume(n);}});
 root.addView(button("RECEIVER NAME",this::rename),new LinearLayout.LayoutParams(-1,dp(54)));
 root.addView(button("PIN / CHANGE PIN",this::pin),new LinearLayout.LayoutParams(-1,dp(60)));root.addView(button("EXIT",()->{stopService(new Intent(this,ReceiverService.class));finish();}),new LinearLayout.LayoutParams(-1,dp(56)));root.addView(text("Teraphonia.com",12)); }
 int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);} TextView text(String s,int n){TextView t=new TextView(this);t.setText(s);t.setTextSize(n);t.setTextColor(Color.WHITE);t.setGravity(Gravity.CENTER);return t;} Button button(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setTextSize(18);b.setOnClickListener(v->r.run());return b;}
 // Current four digits are displayed, and replacement requires matching entries.
 // The SAVE action validates without dismissing the dialog on malformed input.
 void pin(){
   ReceiverService svc=ReceiverService.instance;
   if(svc==null)return;
   LinearLayout contents=new LinearLayout(this);
   contents.setOrientation(LinearLayout.VERTICAL);
   contents.setPadding(dp(20),dp(4),dp(20),dp(4));
   TextView current=text("CURRENT PIN: "+svc.getPin(),22);
   contents.addView(current,new LinearLayout.LayoutParams(-1,dp(54)));
   EditText next=new EditText(this);
   next.setTextSize(22);next.setSingleLine(true);
   next.setHint("NEW PIN · 4 digits");next.setInputType(InputType.TYPE_CLASS_NUMBER);
   next.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(4)});
   contents.addView(next,new LinearLayout.LayoutParams(-1,dp(62)));
   EditText confirm=new EditText(this);
   confirm.setTextSize(22);confirm.setSingleLine(true);
   confirm.setHint("CONFIRM NEW PIN");confirm.setInputType(InputType.TYPE_CLASS_NUMBER);
   confirm.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(4)});
   contents.addView(confirm,new LinearLayout.LayoutParams(-1,dp(62)));
   TextView error=text("",16);
   error.setTextColor(Color.rgb(255,120,120));
   contents.addView(error);
   TextView note=text("Changing PIN stops current playback and removes all previously paired TERAPHON devices.",14);
   contents.addView(note);
   AlertDialog dlg=new AlertDialog.Builder(this)
     .setTitle("PIN / CHANGE PIN").setView(contents)
     .setNegativeButton("CANCEL",null).setPositiveButton("SAVE",null).create();
   dlg.setOnShowListener(ignored->{
     dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
       String p=next.getText().toString(),q=confirm.getText().toString();
       if(!p.matches("[0-9]{4}")){error.setText("Enter exactly 4 digits");return;}
       if(!p.equals(q)){error.setText("PIN entries do not match");return;}
       if(p.equals(svc.getPin())){error.setText("Choose a different PIN");return;}
       if(!svc.changePin(p)){error.setText("Could not save PIN · try again");return;}
       dlg.dismiss();Toast.makeText(this,"PIN changed · devices must pair again",Toast.LENGTH_LONG).show();
     });
   });
   dlg.show();
 }
 void rename(){
   ReceiverService service=ReceiverService.instance;
   if(service==null)return;
   EditText name=new EditText(this);
   name.setSingleLine();
   name.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
   name.setText(service.getDisplayName());
   name.selectAll();
   AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Receiver name").setView(name)
     .setNegativeButton("CANCEL",null).setPositiveButton("OK",null).create();
   dialog.setOnShowListener(ignored->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
     if(service.rename(name.getText().toString()))dialog.dismiss();
     else name.setError("Enter a name of up to 40 characters");
   }));
   dialog.show();
 }
 void updateMuteButton(boolean muted){
   mute.setText(muted?"| UNMUTE |":"| MUTE |");
 }
 final Runnable refresh=new Runnable(){public void run(){ReceiverService s=ReceiverService.instance;if(s!=null){status.setText(s.status());play.setText(s.pauseAction()?"⏸ PAUSE":"▶ PLAY");updateMuteButton(s.isMuted());volume.setProgress(s.getVolume());}h.postDelayed(this,500);}};
 @Override protected void onStart(){super.onStart();h.post(refresh);}@Override protected void onStop(){h.removeCallbacks(refresh);super.onStop();}
}
