package com.teraphon.receiver;
import android.app.*;import android.os.*;import android.content.*;import android.media.*;import android.net.wifi.WifiManager;import android.net.nsd.NsdManager;import android.net.nsd.NsdServiceInfo;import android.security.keystore.*;import java.security.*;import java.security.cert.X509Certificate;import java.math.BigInteger;import java.util.*;import java.util.concurrent.*;import java.io.*;import java.net.*;import javax.net.ssl.*;import javax.security.auth.x500.X500Principal;import javax.xml.parsers.*;import org.w3c.dom.*;import java.nio.charset.StandardCharsets;
public class ReceiverService extends Service {
 static volatile ReceiverService instance; static final String R="urn:schemas-upnp-org:device:MediaRenderer:1",AV="urn:schemas-upnp-org:service:AVTransport:1",RC="urn:schemas-upnp-org:service:RenderingControl:1",CM="urn:schemas-upnp-org:service:ConnectionManager:1";
 static final String[] paths={"av","rc","cm"}, types={AV,RC,CM};static final String[][] acts={{"SetAVTransportURI","Play","Pause","Stop","GetTransportInfo","GetMediaInfo","GetPositionInfo"},{"GetVolume","SetVolume"},{"GetProtocolInfo"}};
 static final String SINK="http-get:*:audio/L16;rate=44100;channels=2:*,http-get:*:audio/L16;rate=48000;channels=2:*";
 final SecureRandom random=new SecureRandom();final SessionGate gate=new SessionGate(); final Handler main=new Handler(Looper.getMainLooper()); final ExecutorService listeners=Executors.newCachedThreadPool();final ThreadPoolExecutor clients=new ThreadPoolExecutor(6,6,0L,TimeUnit.MILLISECONDS,new ArrayBlockingQueue<>(16));
 private volatile boolean muted;
 volatile boolean running,focusHeld;volatile String stage="STARTING",uri="",lastError="",tlsServerError="",fingerprint="";volatile int volume=80;String pin,id; volatile String displayName;SharedPreferences prefs;Set<String> tokens=new HashSet<>();int failures;long blockedUntil;long generation;ServerSocket plain,tls;NsdManager nsd;NsdManager.RegistrationListener nsdRegistration;MulticastSocket discovery;WifiManager.MulticastLock multicast;PowerManager.WakeLock wake; AudioManager audio;AudioFocusRequest focus;volatile HttpURLConnection stream;volatile AudioTrack track;String transport="STOPPED";
 final SmartAudioState smart = new SmartAudioState();
 String audioEpoch = "";
 int retries;
 final Runnable watchdog = new Runnable() {
  @Override public void run() {
   synchronized (ReceiverService.this) {
    if (!running) return;
    if (smart.leaseExpired(now())) {
     stopLocked("STOPPED", true);
     lastError = "Sender connection lost";
    }
   }
   main.postDelayed(this, 500);
  }
 };
 @Override public IBinder onBind(Intent i){return null;}
 @Override public void onCreate(){super.onCreate();instance=this;prefs=getSharedPreferences("receiver",MODE_PRIVATE);pin=prefs.getString("pin",String.format(Locale.US,"%04d",random.nextInt(10000)));id=prefs.getString("id",UUID.randomUUID().toString());tokens=new HashSet<>(prefs.getStringSet("tokens",Collections.emptySet()));volume=prefs.getInt("volume",80);
 muted=prefs.getBoolean("muted",false);
 displayName=prefs.getString("displayName","TERAPHON Receiver");
 smart.manualPause=prefs.getBoolean("manualPause", false);
 prefs.edit().putString("id",id).putString("pin",pin).apply();audio=getSystemService(AudioManager.class);focus=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(attributes()).setWillPauseWhenDucked(true).setOnAudioFocusChangeListener(change->{if(change<0){synchronized(this){if(focusHeld){focusHeld=false;stopLocked("STOPPED",true);lastError="Audio focus lost";}}}},main).build();NotificationManager nm=getSystemService(NotificationManager.class);nm.createNotificationChannel(new NotificationChannel("receiver","TERAPHON Receiver",NotificationManager.IMPORTANCE_LOW));PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);startForeground(1,new Notification.Builder(this,"receiver").setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("TERAPHON Receiver").setContentText("Ready on local Wi-Fi").setContentIntent(open).setOngoing(true).build());running=true;main.post(watchdog);listeners.execute(this::startNetwork);}
 @Override public int onStartCommand(Intent i,int f,int n){return START_NOT_STICKY;}
 AudioAttributes attributes(){return new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();}
 synchronized boolean focus(boolean want){if(want){if(focusHeld)return true;focusHeld=audio.requestAudioFocus(focus)==AudioManager.AUDIOFOCUS_REQUEST_GRANTED;return focusHeld;}audio.abandonAudioFocusRequest(focus);focusHeld=false;return true;}
 synchronized String getPin(){return pin;}
 String getDisplayName(){return displayName;}
 synchronized boolean rename(String input){
  String name=input.trim();
  if(name.isEmpty()||name.codePointCount(0,name.length())>40||name.codePoints().anyMatch(Character::isISOControl))return false;
  if(!prefs.edit().putString("displayName",name).commit())return false;
  displayName=name;
  // The mDNS instance identifies the service, and SSDP/DNS-SD both resolve
  // the saved name through the live UPnP device description.
  return true;
 }

 // Changing PIN is local-only. Persist the new PIN and revoked pairings atomically
 // before disturbing the active music session, so a storage failure is harmless.
 synchronized boolean changePin(String nextPin){
   if(nextPin==null||!nextPin.matches("[0-9]{4}"))return false;
   if(pin.equals(nextPin))return true;
   if(!prefs.edit().putString("pin",nextPin).putStringSet("tokens",new HashSet<>()).commit())return false;
   stopLocked("STOPPED",true);
   gate.revokeAll();tokens.clear();pin=nextPin;
   failures=0;blockedUntil=0;lastError="PIN changed · all previous pairings revoked";
   return true;
 }
 synchronized boolean playing(){return smart.playing;}
 synchronized boolean pauseAction(){return smart.requested && !smart.manualPause && !uri.isEmpty();}
 int getVolume(){return volume;}
 synchronized void setVolume(int n){volume=Math.max(0,Math.min(100,n));prefs.edit().putInt("volume",volume).apply();applyGain();}
 boolean isMuted(){return muted;}
 synchronized boolean toggleMute(){
  muted=!muted;
  prefs.edit().putBoolean("muted",muted).apply();
  applyGain();
  return muted;
 }
 synchronized void applyGain(){
  if(track!=null)try{track.setVolume(muted?0f:volume/100f);}catch(Exception ignored){}
 }
 synchronized String status(){
  return stage+"\n"+smart.state(!uri.isEmpty(),false)+
   (lastError.isEmpty()?"":"\n"+lastError)+(tlsServerError.isEmpty()?"":"\nSERVER: "+tlsServerError);
 }
 synchronized void toggle(){
  if (uri.isEmpty() || !gate.owns(activeToken)) return;
  requestManualPause(pauseAction());
 }
 synchronized void requestManualPause(boolean pause){
  smart.manualPause=pause;
  prefs.edit().putBoolean("manualPause",smart.manualPause).apply();
  if (!smart.manualPause) { smart.requested=true; smart.recovery=false; retries=0; }
  reconcile();
 }
 synchronized void stopPlayback(){stopLocked("STOPPED",true);}
 String activeToken="";
 long now(){return SystemClock.elapsedRealtime();}
 boolean active(){return !uri.isEmpty()&&(smart.requested||smart.manualPause||smart.negotiated);}

 synchronized void stopLocked(String state,boolean release){
  generation++;
  HttpURLConnection c=stream;stream=null;
  if(c!=null)listeners.execute(c::disconnect);
  AudioTrack t=track;track=null;
  if(t!=null)try{t.pause();t.flush();}catch(Exception ignored){}
  smart.playing=false;
  transport=state;
  if(release){
   gate.clear();activeToken="";uri="";audioEpoch="";smart.open();focus(false);
  }
 }
 synchronized void reconcile(){
  if (uri.isEmpty()) return;
  if (smart.audioWanted()){
   if (!transport.equals("PLAYING")&&!transport.equals("TRANSITIONING")) playLocked();
  } else {
   String next = smart.manualPause || !smart.requested ? "PAUSED_PLAYBACK"
     : smart.recovery ? "STOPPED" : "TRANSITIONING";
   if (!transport.equals(next) || stream!=null || track!=null) stopLocked(next,false);
   if (smart.phase!=SmartAudioState.Phase.STREAM_READY || smart.recovery) {
    focus(false);
   }
  }
 }
 synchronized void playLocked(){
  stopLocked("TRANSITIONING",false);
  lastError="";
  long g=generation;
  String u=uri;
  listeners.execute(()->pcm(g,u));
 }
 synchronized boolean current(long g){return running&&g==generation;}

 void pcm(long g,String url){
  HttpURLConnection c=null;
  AudioTrack t=null;
  try {
   android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_AUDIO);
   c=(HttpURLConnection)new URL(url).openConnection(Proxy.NO_PROXY);
   c.setInstanceFollowRedirects(false);c.setConnectTimeout(5000);c.setReadTimeout(8000);
   synchronized(this){if(!current(g))return;stream=c;}
   String ct=c.getContentType();
   if(c.getResponseCode()!=200||ct==null||!ct.toLowerCase(Locale.US).startsWith("audio/l16")||!ct.contains("channels=2"))
    throw new IOException("Expected L16 stereo");
   int rate=ct.contains("rate=48000")?48000:ct.contains("rate=44100")?44100:0;
   if(rate==0)throw new IOException("Unsupported rate");
   DataInputStream in=new DataInputStream(new BufferedInputStream(c.getInputStream(),16384));
   byte[] bytes=new byte[4096];short[] samples=new short[2048];
   in.readFully(bytes);
   int min=AudioTrack.getMinBufferSize(rate,AudioFormat.CHANNEL_OUT_STEREO,AudioFormat.ENCODING_PCM_16BIT);
   if(min<=0)throw new IOException("Audio buffer unavailable");
   t=new AudioTrack.Builder().setAudioAttributes(attributes()).setAudioFormat(
     new AudioFormat.Builder().setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
      .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).build())
      .setBufferSizeInBytes(Math.max(min*4,32768)).setTransferMode(AudioTrack.MODE_STREAM).build();
   synchronized(this){
    if(!current(g)||!smart.audioWanted())return;
    if(!focus(true))throw new IOException("Audio focus denied");
    track=t;applyGain();t.play();
   }
   do {
    for(int i=0;i<samples.length;i++)samples[i]=(short)(((bytes[2*i]&255)<<8)|(bytes[2*i+1]&255));
    int off=0;
    while(off<samples.length&&current(g)){
     int n=t.write(samples,off,samples.length-off,AudioTrack.WRITE_BLOCKING);
     if(n<=0)throw new IOException("AudioTrack "+n);
     off+=n;
    }
    synchronized(this){
     if(!current(g))return;
     if(!smart.playing){smart.playing=true;transport="PLAYING";}
    }
    in.readFully(bytes);
   } while(current(g));
  }catch(Exception e){
   synchronized(this){if(current(g))lastError=e.getClass().getSimpleName()+": "+e.getMessage();}
  }finally{
   if(c!=null)c.disconnect();
   synchronized(this){
    if(current(g)){
     stream=null;
     if(smart.negotiated){
      stopLocked("STOPPED",false);
      smart.recovery=true;focus(false);
      final long failedGeneration=generation;
      if(++retries<=3)main.postDelayed(()->{synchronized(this){
       if(current(failedGeneration)&&smart.recovery&&!smart.leaseExpired(now())){
        smart.recovery=false;reconcile();
       }
      }},750L*retries);
     }else stopLocked("STOPPED",true);
    }
   }
   if(t!=null)try{t.release();}catch(Exception ignored){}
  }
 }

 Reply smartControl(String method,Map<String,String> headers,String token,String body,boolean manual){
  if(!gate.owns(token)||uri.isEmpty()||!uri.equals(headers.get("x-tera-stream")))return err(409,"Wrong stream");
  if(smart.leaseExpired(now())){stopLocked("STOPPED",true);return err(409,"Session expired");}
  if(method.equals("GET")&&!manual)return ok(audioEpoch);
  if(!method.equals("POST"))return err(405,"Method");
  if(!audioEpoch.equals(headers.get("x-tera-epoch")))return err(409,"Wrong session");
  String[] event=body.split(" ",-1);
  if(event.length!=2||!event[0].matches("[1-9][0-9]{0,17}"))return err(400,"Invalid event");
  long sequence=Long.parseLong(event[0]);
  if(manual){
   if(!event[1].equals("PAUSE")&&!event[1].equals("PLAY"))return err(400,"Invalid transport");
   if(!smart.signal(sequence,smart.phase,now()))return err(409,"Old event");
   requestManualPause(event[1].equals("PAUSE"));
   return ok(smart.state(true,false).name());
  }
  SmartAudioState.Phase phase;
  try{phase=SmartAudioState.Phase.valueOf(event[1]);}catch(IllegalArgumentException e){return err(400,"Invalid event");}
  SmartAudioState.Phase before=smart.phase;
  if(!smart.signal(sequence,phase,now()))return err(409,"Old event");
  if(before!=phase)retries=0;
  reconcile();
  return ok(smart.state(true,false).name());
 }
 String hex(byte[] a){StringBuilder b=new StringBuilder();for(byte v:a)b.append(String.format(Locale.US,"%02x",v&255));return b.toString();}String hash(String s)throws Exception{return hex(MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8)));}String newToken(){byte[] b=new byte[32];random.nextBytes(b);return hex(b);}
 SSLContext createTls()throws Exception{String alias="tera_receiver_tls_v2";KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(!ks.containsAlias(alias)){Calendar end=Calendar.getInstance();end.add(Calendar.YEAR,25);KeyPairGenerator generator=KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA,"AndroidKeyStore");generator.initialize(new KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_SIGN|KeyProperties.PURPOSE_DECRYPT).setKeySize(2048).setDigests(KeyProperties.DIGEST_NONE,KeyProperties.DIGEST_SHA256,KeyProperties.DIGEST_SHA384,KeyProperties.DIGEST_SHA512).setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1,KeyProperties.SIGNATURE_PADDING_RSA_PSS).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE,KeyProperties.ENCRYPTION_PADDING_RSA_PKCS1).setCertificateSubject(new X500Principal("CN=TERAPHON Receiver Android")).setCertificateSerialNumber(BigInteger.ONE).setCertificateNotBefore(new Date(System.currentTimeMillis()-86400000L)).setCertificateNotAfter(end.getTime()).build());generator.generateKeyPair();}X509Certificate cert=(X509Certificate)ks.getCertificate(alias);fingerprint=hex(MessageDigest.getInstance("SHA-256").digest(cert.getEncoded()));PrivateKey key=(PrivateKey)ks.getKey(alias,null);X509ExtendedKeyManager km=new X509ExtendedKeyManager(){public String[] getClientAliases(String t,Principal[] p){return null;}public String chooseClientAlias(String[] t,Principal[] p,Socket s){return null;}public String[] getServerAliases(String t,Principal[] p){return rsa(t)?new String[]{alias}:null;}
public String chooseServerAlias(String t,Principal[] p,Socket s){return rsa(t)?alias:null;}
@Override public String chooseEngineServerAlias(String t,Principal[] p,SSLEngine e){return rsa(t)?alias:null;}
private boolean rsa(String t){return t!=null&&t.toUpperCase(Locale.US).contains("RSA");}
public X509Certificate[] getCertificateChain(String a){return new X509Certificate[]{cert};}public PrivateKey getPrivateKey(String a){return key;}};SSLContext sc=SSLContext.getInstance("TLS");sc.init(new KeyManager[]{km},null,random);return sc;}
 void startNetwork(){try{SSLContext ssl=createTls();if(!running)return;plain=new ServerSocket(49152);tls=ssl.getServerSocketFactory().createServerSocket(49153);if(!running){plain.close();tls.close();return;}SSLServerSocket tlsServer=(SSLServerSocket)tls;
tlsServer.setUseClientMode(false);
// Restrict the listener to modern TLS; enable TLS 1.3 when this Android build supports it.
List<String> protocols=Arrays.asList(tlsServer.getSupportedProtocols());
tlsServer.setEnabledProtocols(new String[]{"TLSv1.2"});WifiManager wm=(WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);multicast=wm.createMulticastLock("tera_receiver");multicast.setReferenceCounted(false);multicast.acquire();PowerManager pm=getSystemService(PowerManager.class);wake=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"teraphon:receiver");wake.acquire();stage="READY · ANDROID";registerNsd();listeners.execute(()->accept(plain,false));listeners.execute(()->accept(tls,true));listeners.execute(this::ssdp);listeners.execute(this::checkTls);}catch(Exception e){stage="NETWORK ERROR";lastError=e.toString();}}
 // DNS-SD advertises the exact same authenticated UPnP endpoint used by Windows.
 // SSDP stays as a fallback for routers that block mDNS. No IP entry required.
 void registerNsd(){try{
   nsd=(NsdManager)getSystemService(NSD_SERVICE);
   if(nsd==null)return;
   NsdServiceInfo info=new NsdServiceInfo();
   info.setServiceName("TERAPHON Receiver "+Build.MODEL);
   info.setServiceType("_teraphon._tcp.");
   info.setPort(49152);
   info.setAttribute("id",id);
   info.setAttribute("fn","TERAPHON Receiver "+Build.MODEL);
   nsdRegistration=new NsdManager.RegistrationListener(){
      @Override public void onRegistrationFailed(NsdServiceInfo info,int code){lastError="mDNS publish failed ("+code+")";}
      @Override public void onUnregistrationFailed(NsdServiceInfo info,int code){}
      @Override public void onServiceRegistered(NsdServiceInfo info){}
      @Override public void onServiceUnregistered(NsdServiceInfo info){}
   };
   nsd.registerService(info,NsdManager.PROTOCOL_DNS_SD,nsdRegistration);
 }catch(Exception e){lastError="mDNS: "+e.getMessage();}}
 // A local end-to-end secure request catches bad key selection/SSL configuration before pairing.
 // The certificate is pinned exactly as the TERAPHON sender does. No external request or PIN is used.
 void checkTls(){
   try {
     final String expected=fingerprint;
     X509TrustManager pinned=new X509TrustManager(){
       @Override public X509Certificate[] getAcceptedIssuers(){return new X509Certificate[0];}
       @Override public void checkClientTrusted(X509Certificate[] chain,String auth)throws java.security.cert.CertificateException{throw new java.security.cert.CertificateException("No client certificates");}
       @Override public void checkServerTrusted(X509Certificate[] chain,String auth)throws java.security.cert.CertificateException{
         if(chain==null||chain.length<1)throw new java.security.cert.CertificateException("No server certificate");
         try{
           chain[0].checkValidity();
           String actual=hex(MessageDigest.getInstance("SHA-256").digest(chain[0].getEncoded()));
           if(!MessageDigest.isEqual(actual.getBytes(StandardCharsets.US_ASCII),expected.getBytes(StandardCharsets.US_ASCII)))throw new java.security.cert.CertificateException("Local certificate pin mismatch");
         }catch(GeneralSecurityException e){throw new java.security.cert.CertificateException("TLS certificate rejected",e);}
       }
     };
     SSLContext test=SSLContext.getInstance("TLS");test.init(null,new TrustManager[]{pinned},random);
     HttpsURLConnection connection=(HttpsURLConnection)new URL("https://127.0.0.1:49153/availability").openConnection(Proxy.NO_PROXY);
     connection.setSSLSocketFactory(test.getSocketFactory());
     connection.setHostnameVerifier((host,session)->host.equals("127.0.0.1"));
     connection.setConnectTimeout(5000);connection.setReadTimeout(5000);
     try {int status=connection.getResponseCode();if(status!=200)throw new IOException("HTTPS /availability returned "+status);}
     finally{connection.disconnect();}
     if(running){android.util.Log.i("TERAPHON_RECEIVER","Pinned HTTPS check OK");stage="READY · HTTPS OK";lastError="";tlsServerError="";}
   }catch(Exception e){
     if(running){stage="HTTPS ERROR";lastError="TLS self-test: "+errorMessage(e);android.util.Log.e("TERAPHON_RECEIVER",lastError,e);}
   }
 }
 static String errorMessage(Throwable e){
   StringBuilder b=new StringBuilder();int depth=0;
   while(e!=null&&depth++<3){if(b.length()>0)b.append(" → ");b.append(e.getClass().getSimpleName());
     String msg=e.getMessage();if(msg!=null&&!msg.isEmpty())b.append(": ").append(msg.length()>160?msg.substring(0,160):msg);
     e=e.getCause();}return b.toString();
 }
 void accept(ServerSocket server,boolean secure){while(running)try{Socket s=server.accept();if(!local(s.getInetAddress())){s.close();continue;}try{clients.execute(()->handle(s,secure));}catch(RejectedExecutionException e){s.close();}}catch(Exception e){if(running)lastError=e.toString();break;}}
 static boolean local(InetAddress a){return a.isSiteLocalAddress()||a.isLinkLocalAddress()||a.isLoopbackAddress();}
 void ssdp(){try{discovery=new MulticastSocket(null);discovery.setReuseAddress(true);discovery.bind(new InetSocketAddress(1900));InetAddress group=InetAddress.getByName("239.255.255.250");Enumeration<NetworkInterface> ifs=NetworkInterface.getNetworkInterfaces();while(ifs.hasMoreElements()){NetworkInterface ni=ifs.nextElement();if(ni.isUp()&&!ni.isLoopback()&&ni.supportsMulticast())try{discovery.joinGroup(new InetSocketAddress(group,1900),ni);}catch(Exception ignored){}}byte[] b=new byte[8192];while(running){DatagramPacket p=new DatagramPacket(b,b.length);discovery.receive(p);String s=new String(b,0,p.getLength(),StandardCharsets.US_ASCII).toLowerCase(Locale.US);if(!s.startsWith("m-search")||!s.contains("ssdp:discover")||!local(p.getAddress())||!(p.getAddress() instanceof Inet4Address))continue;String st="";for(String l:s.split("\n"))if(l.startsWith("st:"))st=l.substring(3).trim();if(!Arrays.asList("ssdp:all",R.toLowerCase(Locale.US),AV.toLowerCase(Locale.US),"upnp:rootdevice").contains(st))continue;String target=st.equals("upnp:rootdevice")?st:st.equals(AV.toLowerCase(Locale.US))?AV:R;try(DatagramSocket out=new DatagramSocket()){out.connect(p.getAddress(),p.getPort());String ip=out.getLocalAddress().getHostAddress();String msg="HTTP/1.1 200 OK\r\nCACHE-CONTROL: max-age=120\r\nEXT:\r\nLOCATION: http://"+ip+":49152/description.xml\r\nST: "+target+"\r\nUSN: uuid:"+id+"::"+target+"\r\nSERVER: Android UPnP/1.0 TERAPHON/1.0\r\n\r\n";byte[] data=msg.getBytes(StandardCharsets.US_ASCII);out.send(new DatagramPacket(data,data.length,p.getAddress(),p.getPort()));}}}catch(Exception e){if(running)lastError="Discovery: "+e.getMessage();}}
 static String esc(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");}String description(){StringBuilder b=new StringBuilder("<?xml version=\"1.0\"?><root xmlns=\"urn:schemas-upnp-org:device-1-0\"><specVersion><major>1</major><minor>0</minor></specVersion><device><deviceType>"+R+"</deviceType><friendlyName>"+esc(displayName)+"</friendlyName><manufacturer>Teraphonia</manufacturer><modelName>Teraphon Receiver Android</modelName><UDN>uuid:"+id+"</UDN><teraFingerprint>"+fingerprint+"</teraFingerprint><teraTlsPort>49153</teraTlsPort><serviceList>");for(int i=0;i<3;i++)b.append("<service><serviceType>"+types[i]+"</serviceType><serviceId>urn:upnp-org:serviceId:"+paths[i]+"</serviceId><SCPDURL>/"+paths[i]+".xml</SCPDURL><controlURL>/"+paths[i]+"/control</controlURL><eventSubURL>/"+paths[i]+"/event</eventSubURL></service>");return b+"</serviceList></device></root>";}
 String scpd(int i){StringBuilder b=new StringBuilder("<scpd xmlns=\"urn:schemas-upnp-org:service-1-0\"><actionList>");for(String a:acts[i])b.append("<action><name>"+a+"</name></action>");return b+"</actionList><serviceStateTable/></scpd>";}
 static class Reply{int code;String body;boolean xml;Reply(int c,String b){code=c;body=b;}Reply xml(){xml=true;return this;}}Reply ok(String b){return new Reply(200,b);}Reply err(int c,String b){return new Reply(c,b);}
 String line(InputStream in)throws IOException{ByteArrayOutputStream b=new ByteArrayOutputStream();int c;while((c=in.read())!=-1){if(c==10)return b.toString("UTF-8").replace("\r","");if(b.size()>16384)throw new IOException("header too long");b.write(c);}throw new EOFException();}
 void handle(Socket socket,boolean secure){try(Socket s=socket){s.setSoTimeout(8000);if(secure && s instanceof SSLSocket)((SSLSocket)s).startHandshake();InputStream in=new BufferedInputStream(s.getInputStream());String[] first=line(in).split(" ");if(first.length!=3)return;Map<String,String> headers=new HashMap<>();for(int i=0;i<64;i++){String l=line(in);if(l.isEmpty())break;int j=l.indexOf(':');if(j<1)throw new IOException("invalid header");headers.put(l.substring(0,j).toLowerCase(Locale.US),l.substring(j+1).trim());if(i==63)throw new IOException("too many headers");}int n=Integer.parseInt(headers.getOrDefault("content-length","0"));if(n<0||n>524288||headers.containsKey("transfer-encoding"))return;byte[] data=new byte[n];new DataInputStream(in).readFully(data);Reply r;
try{r=route(first[0],first[1],headers,new String(data,StandardCharsets.UTF_8),secure,s.getInetAddress());}
catch(Exception problem){
  if(running){lastError="HTTP route: "+errorMessage(problem);android.util.Log.w("TERAPHON_RECEIVER",lastError);}
  r=err(500,"Receiver request error");
}
byte[] out=r.body.getBytes(StandardCharsets.UTF_8);OutputStream os=s.getOutputStream();os.write(("HTTP/1.1 "+r.code+" "+(r.code==200?"OK":"Error")+"\r\nContent-Type: "+(r.xml?"text/xml":"text/plain")+"; charset=utf-8\r\nCache-Control: no-store\r\nContent-Length: "+out.length+"\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII));os.write(out);os.flush();}catch(Exception e){
   if(running && secure && !(e instanceof EOFException) && !(e instanceof SocketTimeoutException)){
     tlsServerError=errorMessage(e);
     android.util.Log.w("TERAPHON_RECEIVER","HTTPS server: "+tlsServerError,e);
   }
 }}
 String field(String xml,String name)throws Exception{if(xml.contains("<!DOCTYPE")||xml.contains("<!ENTITY"))throw new IOException("DTD not allowed");org.xmlpull.v1.XmlPullParser p=android.util.Xml.newPullParser();p.setFeature(org.xmlpull.v1.XmlPullParser.FEATURE_PROCESS_NAMESPACES,true);p.setInput(new StringReader(xml));for(int e=p.getEventType();e!=org.xmlpull.v1.XmlPullParser.END_DOCUMENT;e=p.next()){if(e==org.xmlpull.v1.XmlPullParser.START_TAG&&name.equals(p.getName()))return p.nextText();}return "";}
 Reply soap(String typ,String a,String body){return ok("<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\"><s:Body><u:"+a+"Response xmlns:u=\""+typ+"\">"+body+"</u:"+a+"Response></s:Body></s:Envelope>").xml();}
 boolean allowed(String raw,InetAddress peer){try{URI u=new URI(raw);return "http".equals(u.getScheme())&&u.getUserInfo()==null&&u.getFragment()==null&&u.getPort()>0&&u.getHost()!=null&&u.getHost().matches("[0-9.]+")&&InetAddress.getByName(u.getHost()).equals(peer)&&u.getPath().startsWith("/master/")&&u.getPath().endsWith("/live");}catch(Exception e){return false;}}
 synchronized Reply route(String method,String path,Map<String,String> h,String body,boolean secure,InetAddress peer)throws Exception{String auth=h.getOrDefault("authorization","");String token=auth.matches("Bearer [a-f0-9]{64}")?hash(auth.substring(7)):"";boolean valid=tokens.contains(token);long now=now();if(method.equals("GET")&&path.equals("/description.xml"))return ok(description()).xml();for(int i=0;i<3;i++)if(method.equals("GET")&&path.equals("/"+paths[i]+".xml"))return ok(scpd(i)).xml();String action=h.getOrDefault("soapaction","").replace("\"","");action=action.substring(action.lastIndexOf('#')+1);if(method.equals("POST")&&path.equals("/cm/control")&&action.equals("GetProtocolInfo"))return soap(CM,action,"<Source></Source><Sink>"+esc(SINK)+"</Sink>");if(!secure)return err(403,"TLS required");if(path.equals("/availability")&&method.equals("GET"))return ok("AVAILABLE");if(path.equals("/pair")&&method.equals("POST")){if(now<blockedUntil)return err(429,"Wait one minute");if(!MessageDigest.isEqual(body.getBytes(StandardCharsets.UTF_8),pin.getBytes(StandardCharsets.UTF_8))){if(++failures>=5){blockedUntil=now+60000;failures=0;}return err(401,"Incorrect PIN");}failures=0;if(valid){if(path.equals("/pair"))gate.arm(token,now);return ok(auth.substring(7));}if(tokens.size()>=128)return err(409,"Change PIN to clear pairings");String fresh=newToken();String digest=hash(fresh);tokens.add(digest);if(!prefs.edit().putStringSet("tokens",new HashSet<>(tokens)).commit()){tokens.remove(digest);return err(500,"Cannot store pairing");}if(path.equals("/pair"))gate.arm(digest,now);return ok(fresh);}if(!valid)return err(401,"Pair first");if(path.equals("/receiver/audio")||path.equals("/receiver/transport"))return smartControl(method,h,token,body,path.equals("/receiver/transport"));
if(path.equals("/receiver/mute")&&method.equals("GET")&&gate.owns(token))return ok("UNMUTED");if(path.equals("/status")&&method.equals("GET")){gate.arm(token,now);return ok("READY");}if(gate.busy(token,now,active())&&!(method.equals("POST")&&path.equals("/av/control")&&action.equals("SetAVTransportURI")))return err(423,"RECEIVER BUSY");if(!method.equals("POST"))return err(404,"Not found");int ix=path.equals("/av/control")?0:path.equals("/rc/control")?1:-1;if(ix<0||!Arrays.asList(acts[ix]).contains(action))return err(404,"Unknown action");if(gate.owns(token))gate.claim(token,now,active());String output="";try{switch(action){case "SetAVTransportURI":String u=field(body,"CurrentURI");if(!allowed(u,peer))return err(400,"Invalid local PCM URL");
// Only an authenticated, validated playback request takes over. PIN entry, discovery
// and /status NEVER interrupt the previous source while the newcomer grants consent.
if(!gate.canStart(token,now))return err(423,"Reconnect to take over");boolean newOwner=!gate.owns(token);stopLocked("STOPPED",false);

if(!gate.takeover(token,now))return err(423,"Reconnect to take over");
if(newOwner||!uri.equals(u)){smart.open();audioEpoch=newToken();retries=0;}
activeToken=token;uri=u;
// Hold existing Audio Focus across the quick switch to prevent local players
// from briefly resuming; release it if the new source never starts.
final long pendingGeneration=generation;final String pendingOwner=token;
main.postDelayed(()->{synchronized(ReceiverService.this){if(current(pendingGeneration)&&gate.owns(pendingOwner)&&!active()){stopLocked("STOPPED",true);lastError="Waiting for sender timed out";}}},30000L);
break;case "Play":if(!gate.owns(token)||uri.isEmpty())return err(409,"No stream");smart.requested=true;reconcile();break;case "Pause":if(!gate.owns(token))return err(409,"No session");smart.requested=false;reconcile();break;case "Stop":if(!gate.owns(token))return err(409,"No session");stopLocked("STOPPED",true);break;case "GetTransportInfo":output="<CurrentTransportState>"+transport+"</CurrentTransportState><CurrentTransportStatus>OK</CurrentTransportStatus><CurrentSpeed>1</CurrentSpeed>";break;case "GetMediaInfo":output="<CurrentURI>"+esc(uri)+"</CurrentURI><NrTracks>1</NrTracks>";break;case "GetPositionInfo":output="<Track>1</Track><TrackURI>"+esc(uri)+"</TrackURI><RelTime>00:00:00</RelTime>";break;case "GetVolume":output="<CurrentVolume>"+volume+"</CurrentVolume>";break;case "SetVolume":if(!gate.owns(token))return err(409,"No session");int v=Integer.parseInt(field(body,"DesiredVolume"));if(v<0||v>100)return err(400,"Volume");setVolume(v);break;default:return err(400,"Action");}}catch(Exception e){return err(400,"Invalid SOAP request");}return soap(types[ix],action,output);}
 @Override public void onDestroy(){running=false;main.removeCallbacks(watchdog);synchronized(this){stopLocked("STOPPED",true);}try{if(plain!=null)plain.close();if(tls!=null)tls.close();if(discovery!=null)discovery.close();}catch(Exception ignored){}try{if(nsd!=null&&nsdRegistration!=null)nsd.unregisterService(nsdRegistration);}catch(Exception ignored){}if(multicast!=null&&multicast.isHeld())multicast.release();if(wake!=null&&wake.isHeld())wake.release();clients.shutdownNow();listeners.shutdown();instance=null;super.onDestroy();}
}
