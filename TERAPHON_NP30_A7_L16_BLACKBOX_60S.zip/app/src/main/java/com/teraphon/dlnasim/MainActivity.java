package com.teraphon.dlnasim;

import android.app.*; import android.os.*; import android.content.*; import android.graphics.Color; import android.view.*; import android.widget.*; import android.media.MediaPlayer; import android.media.AudioTrack; import android.media.AudioFormat; import android.media.AudioManager; import android.content.ClipData; import android.content.ClipboardManager; import android.net.wifi.WifiManager;
import java.net.*; import java.io.*; import java.nio.charset.StandardCharsets; import java.util.*; import java.util.concurrent.*;

public class MainActivity extends Activity {
 TextView status, detail; MediaPlayer player; AudioTrack track; volatile boolean audioActive=false; Thread audioThread;
 final ArrayDeque<LogEntry> events=new ArrayDeque<>();
 static class LogEntry {long t; String msg; LogEntry(long t,String msg){this.t=t;this.msg=msg;}}
 synchronized void log(String message){long now=System.currentTimeMillis();events.addLast(new LogEntry(now,message));while(!events.isEmpty()&&events.peekFirst().t<now-60000)events.removeFirst();}
 synchronized String getLog(){long now=System.currentTimeMillis();StringBuilder b=new StringBuilder("TERAPHON NP30 A7 — BLACK BOX last 60 seconds\\n");for(LogEntry e:events)if(now-e.t<=60000)b.append(new java.text.SimpleDateFormat("HH:mm:ss.SSS",Locale.US).format(new Date(e.t))).append("  ").append(e.msg).append('\\n');return b.toString();}
  WifiManager.MulticastLock lock; volatile boolean running=false; ServerSocket http; MulticastSocket ssdp; ExecutorService pool=Executors.newCachedThreadPool(); String uuid="uuid:7f4f28e0-22cd-45a2-b190-teraphon-dlna-test"; String current=""; int port=0;
 void ui(String a,String b){runOnUiThread(()->{status.setText(a); detail.setText(b);});}
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().addFlags(128); LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(Color.BLACK);root.setPadding(22,35,22,25); TextView title=new TextView(this);title.setText("TERAPHON\nDLNA TEST");title.setTextColor(Color.WHITE);title.setTextSize(36);title.setGravity(17);root.addView(title); status=new TextView(this);status.setText("READY");status.setTextSize(46);status.setTextColor(Color.GREEN);status.setGravity(17);root.addView(status,new LinearLayout.LayoutParams(-1,0,1));detail=new TextView(this);detail.setText("Tap START\nSame Wi-Fi as TERAPHON");detail.setTextSize(24);detail.setTextColor(Color.WHITE);detail.setGravity(17);root.addView(detail,new LinearLayout.LayoutParams(-1,0,1));Button start=new Button(this);start.setText("START / RESTART");start.setTextSize(25);root.addView(start,new LinearLayout.LayoutParams(-1,110));start.setOnClickListener(v->start());Button stop=new Button(this);stop.setText("STOP AUDIO");stop.setTextSize(25);root.addView(stop,new LinearLayout.LayoutParams(-1,100));stop.setOnClickListener(v->stopAudio());Button copy=new Button(this);copy.setText("COPY 60 SEC LOG");copy.setTextSize(24);root.addView(copy,new LinearLayout.LayoutParams(-1,95));copy.setOnClickListener(v->{((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("NP30 A7 log",getLog()));ui(status.getText().toString(),"60-second log copied");});
 Button save=new Button(this);save.setText("SAVE 60 SEC LOG");save.setTextSize(24);root.addView(save,new LinearLayout.LayoutParams(-1,95));save.setOnClickListener(v->{try{File dir=getExternalFilesDir(null);File f=new File(dir,"NP30_A7_60SEC_"+System.currentTimeMillis()+".txt");try(FileOutputStream o=new FileOutputStream(f)){o.write(getLog().getBytes(StandardCharsets.UTF_8));}ui(status.getText().toString(),"Log saved: "+f.getAbsolutePath());}catch(Exception e){log("SAVE ERROR "+e);ui("ERROR",e.toString());}});
 setContentView(root);log("START simulator");start();}
 void start(){if(running)return;running=true;pool.execute(()->{try{http=new ServerSocket(0);port=http.getLocalPort();WifiManager wifi=(WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);lock=wifi.createMulticastLock("teraphon-dlna");lock.setReferenceCounted(false);lock.acquire();ui("READY","DLNA receiver running\nPort "+port+"\nWaiting for TERAPHON");pool.execute(this::ssdpLoop);while(running){Socket s=http.accept();pool.execute(()->handle(s));}}catch(Exception e){ui("ERROR",e.toString());}});}
 String ip(){try{Enumeration<NetworkInterface> all=NetworkInterface.getNetworkInterfaces();while(all.hasMoreElements()){NetworkInterface n=all.nextElement();if(!n.isUp()||n.isLoopback())continue;Enumeration<InetAddress> addresses=n.getInetAddresses();while(addresses.hasMoreElements()){InetAddress a=addresses.nextElement();if(a instanceof Inet4Address && a.isSiteLocalAddress())return a.getHostAddress();}}}catch(Exception ignored){}return "127.0.0.1";}
 String location(){return "http://"+ip()+":"+port+"/desc.xml";}
 String deviceXml(){return "<?xml version=\"1.0\"?><root xmlns=\"urn:schemas-upnp-org:device-1-0\"><specVersion><major>1</major><minor>0</minor></specVersion><device><deviceType>urn:schemas-upnp-org:device:MediaRenderer:1</deviceType><friendlyName>Cambridge NP30 TEST - TERAPHON</friendlyName><manufacturer>TERAPHON Test</manufacturer><modelName>NP30 DLNA Test Receiver</modelName><UDN>"+uuid+"</UDN><serviceList><service><serviceType>urn:schemas-upnp-org:service:AVTransport:1</serviceType><serviceId>urn:upnp-org:serviceId:AVTransport</serviceId><SCPDURL>/av.xml</SCPDURL><controlURL>/av/control</controlURL><eventSubURL>/av/event</eventSubURL></service><service><serviceType>urn:schemas-upnp-org:service:ConnectionManager:1</serviceType><serviceId>urn:upnp-org:serviceId:ConnectionManager</serviceId><SCPDURL>/cm.xml</SCPDURL><controlURL>/cm/control</controlURL><eventSubURL>/cm/event</eventSubURL></service></serviceList></device></root>";}
 String scpd(boolean av){String actions=av?"SetAVTransportURI,Play,Pause,Stop,GetTransportInfo,GetPositionInfo":"GetProtocolInfo,GetCurrentConnectionIDs";StringBuilder b=new StringBuilder("<?xml version=\"1.0\"?><scpd xmlns=\"urn:schemas-upnp-org:service-1-0\"><specVersion><major>1</major><minor>0</minor></specVersion><actionList>");for(String a:actions.split(","))b.append("<action><name>").append(a).append("</name></action>");return b.append("</actionList><serviceStateTable></serviceStateTable></scpd>").toString();}
 String tag(String xml,String name){try{java.util.regex.Matcher m=java.util.regex.Pattern.compile("<(?:[\\w-]+:)?"+name+"(?:\\s[^>]*)?>(.*?)</(?:[\\w-]+:)?"+name+">",java.util.regex.Pattern.DOTALL).matcher(xml);return m.find()?m.group(1).replace("&amp;","&").replace("&lt;","<").replace("&gt;",">"):"";}catch(Exception e){return "";}}
 void handle(Socket socket){try(Socket s=socket){s.setSoTimeout(10000);BufferedInputStream in=new BufferedInputStream(s.getInputStream());ByteArrayOutputStream hdr=new ByteArrayOutputStream();int c;while((c=in.read())!=-1){hdr.write(c);byte[] v=hdr.toByteArray();int n=v.length;if(n>=4&&v[n-4]=='\r'&&v[n-3]=='\n'&&v[n-2]=='\r'&&v[n-1]=='\n')break;if(n>32768)return;}String headers=hdr.toString("UTF-8");String[] first=headers.split("\\r?\\n")[0].split(" ");String path=first.length>1?first[1]:"/";int length=0;for(String line:headers.split("\\r?\\n"))if(line.toLowerCase(Locale.ROOT).startsWith("content-length:"))length=Integer.parseInt(line.substring(line.indexOf(':')+1).trim());byte[] body=new byte[Math.min(length,1000000)];int pos=0;while(pos<body.length){int k=in.read(body,pos,body.length-pos);if(k<0)break;pos+=k;}String xml=new String(body,0,pos,StandardCharsets.UTF_8);String result="";String mime="text/xml";if(path.equals("/desc.xml"))result=deviceXml();else if(path.equals("/av.xml"))result=scpd(true);else if(path.equals("/cm.xml"))result=scpd(false);else if(path.equals("/av/control")){String action="";for(String line:headers.split("\\r?\\n"))if(line.toLowerCase(Locale.ROOT).startsWith("soapaction:")){action=line.substring(line.lastIndexOf('#')+1).replace("\"","").trim();break;}result=soap(action,xml,true);}else if(path.equals("/cm/control")){String action=xml.contains("GetProtocolInfo")?"GetProtocolInfo":"GetCurrentConnectionIDs";result=soap(action,xml,false);}else if(path.endsWith("/event")){result="";}else {result="Not found";mime="text/plain";}byte[] bytes=result.getBytes(StandardCharsets.UTF_8);OutputStream out=s.getOutputStream();out.write(("HTTP/1.1 200 OK\r\nContent-Type: "+mime+"; charset=utf-8\r\nContent-Length: "+bytes.length+"\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.UTF_8));out.write(bytes);out.flush();}catch(Exception e){ui("ERROR",e.toString());}}
 String soap(String action,String xml,boolean av){String ns=av?"urn:schemas-upnp-org:service:AVTransport:1":"urn:schemas-upnp-org:service:ConnectionManager:1";String contents="";switch(action){case "SetAVTransportURI":current=tag(xml,"CurrentURI");log("SetAVTransportURI "+current);ui("CONNECTED","Media URI received\n"+current);break;case "Play":log("UPnP Play");play();break;case "Stop":log("UPnP Stop");stopAudio();break;case "Pause":runOnUiThread(()->{if(player!=null&&player.isPlaying())player.pause();});ui("PAUSED",current);break;case "GetTransportInfo":contents="<CurrentTransportState>"+(track!=null&&track.getPlayState()==AudioTrack.PLAYSTATE_PLAYING?"PLAYING":"STOPPED")+"</CurrentTransportState><CurrentTransportStatus>OK</CurrentTransportStatus><CurrentSpeed>1</CurrentSpeed>";break;case "GetPositionInfo":contents="<Track>1</Track><TrackDuration>00:00:00</TrackDuration><TrackMetaData></TrackMetaData><TrackURI>"+escape(current)+"</TrackURI><RelTime>00:00:00</RelTime><AbsTime>00:00:00</AbsTime><RelCount>0</RelCount><AbsCount>0</AbsCount>";break;case "GetProtocolInfo":contents="<Source></Source><Sink>http-get:*:audio/L16:*,http-get:*:audio/wav:*,http-get:*:audio/x-wav:*,http-get:*:audio/mpeg:*,http-get:*:audio/aac:*</Sink>";break;case "GetCurrentConnectionIDs":contents="<ConnectionIDs>0</ConnectionIDs>";break;}return "<?xml version=\"1.0\"?><s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body><u:"+action+"Response xmlns:u=\""+ns+"\">"+contents+"</u:"+action+"Response></s:Body></s:Envelope>";}
 String escape(String s){return s.replace("&","&amp;").replace("<","&lt;");}

 void play(){
   String url=current;
   stopAudio();
   audioActive=true;
   log("PLAY URI="+url);
   ui("CONNECTING",url);
   audioThread=new Thread(()->receiveAudio(url),"NP30-PCM");
   audioThread.start();
 }
 void receiveAudio(String url){
   HttpURLConnection conn=null;
   try{
     conn=(HttpURLConnection)new URL(url).openConnection();
     conn.setConnectTimeout(7000);conn.setReadTimeout(12000);
     conn.setRequestProperty("Accept","audio/L16, audio/wav, audio/x-wav, */*");
     int code=conn.getResponseCode();
     String type=conn.getContentType();
     log("HTTP "+code+" type="+type+" len="+conn.getHeaderField("Content-Length")+" transfer="+conn.getHeaderField("Transfer-Encoding"));
     if(code!=200&&code!=206)throw new IOException("HTTP "+code);
     InputStream in=new BufferedInputStream(conn.getInputStream(),32768);
     boolean wav=(type!=null&&type.toLowerCase(Locale.US).contains("wav"))||url.toLowerCase(Locale.US).endsWith(".wav");
     int rate=44100, channels=2, bits=16;
     byte[] head=new byte[12];int got=0;
     while(got<12){int n=in.read(head,got,12-got);if(n<0)break;got+=n;}
     if(got<12)throw new IOException("No audio data: "+got+" bytes");
     boolean riff=head[0]=='R'&&head[1]=='I'&&head[2]=='F'&&head[3]=='F';
     wav=wav||riff;
     ByteArrayOutputStream prefix=new ByteArrayOutputStream();
     if(wav){
       if(!riff)throw new IOException("WAV MIME but no RIFF header");
       // Walk WAV chunks rather than assuming a fixed 44-byte header.
       while(true){
         byte[] ch=new byte[8];readFully(in,ch,0,8);
         String id=new String(ch,0,4,StandardCharsets.US_ASCII);
         long size=((long)ch[4]&255)|(((long)ch[5]&255)<<8)|(((long)ch[6]&255)<<16)|(((long)ch[7]&255)<<24);
         if("data".equals(id)){log("WAV data chunk len="+size);break;}
         if(size>1048576)throw new IOException("WAV unexpected chunk "+id+" len="+size);
         byte[] data=new byte[(int)size];readFully(in,data,0,data.length);
         if("fmt ".equals(id)){
           if(data.length<16)throw new IOException("WAV fmt too short");
           int fmt=(data[0]&255)|((data[1]&255)<<8);
           channels=(data[2]&255)|((data[3]&255)<<8);
           rate=(data[4]&255)|((data[5]&255)<<8)|((data[6]&255)<<16)|((data[7]&255)<<24);
           bits=(data[14]&255)|((data[15]&255)<<8);
           if(fmt!=1)throw new IOException("WAV not PCM format="+fmt);
         }
         if((size&1)!=0)in.read();
       }
     }else{
       prefix.write(head);
       String t=type==null?"":type.toLowerCase(Locale.US);
       java.util.regex.Matcher m=java.util.regex.Pattern.compile("rate=(\\d+)").matcher(t);
       if(m.find())rate=Integer.parseInt(m.group(1));
       m=java.util.regex.Pattern.compile("channels=(\\d+)").matcher(t);
       if(m.find())channels=Integer.parseInt(m.group(1));
     }
     if(bits!=16||channels!=2||rate<8000||rate>96000)throw new IOException("Unsupported PCM "+rate+"Hz "+channels+"ch "+bits+"bit");
     boolean bigEndian=!wav; // RFC 2586 L16 is network-order signed PCM.
     log("FORMAT "+(wav?"WAV LE":"L16 BE")+" "+rate+"Hz stereo 16-bit");
     int min=AudioTrack.getMinBufferSize(rate,AudioFormat.CHANNEL_OUT_STEREO,AudioFormat.ENCODING_PCM_16BIT);
     if(min<=0)throw new IOException("AudioTrack buffer "+min);
     AudioTrack at=new AudioTrack(AudioManager.STREAM_MUSIC,rate,AudioFormat.CHANNEL_OUT_STEREO,AudioFormat.ENCODING_PCM_16BIT,Math.max(min*4,32768),AudioTrack.MODE_STREAM);
     if(at.getState()!=AudioTrack.STATE_INITIALIZED)throw new IOException("AudioTrack init failed");
     track=at;at.play();ui("PLAYING","MASTER PCM "+rate+" Hz\n"+url);
     byte[] buf=new byte[16384];long total=0;long last=System.currentTimeMillis();
     byte[] pre=prefix.toByteArray();if(pre.length>0){if(bigEndian)swap16(pre,pre.length);at.write(pre,0,pre.length);total+=pre.length;}
     int n;
     while(audioActive&&(n=in.read(buf))!=-1){
       if(n==0)continue;
       if(bigEndian)swap16(buf,n);
       int off=0;while(off<n&&audioActive){int w=at.write(buf,off,n-off);if(w<0)throw new IOException("AudioTrack write="+w);if(w==0)break;off+=w;}
       total+=off;
       long now=System.currentTimeMillis();
       if(now-last>=1000){log("AUDIO received/written="+total+" bytes AudioTrack="+at.getPlayState());last=now;}
     }
     log("END bytes="+total+" active="+audioActive);
     if(audioActive)ui("STOPPED","Stream ended; bytes="+total);
   }catch(Exception e){log("AUDIO ERROR "+e.getClass().getSimpleName()+": "+e.getMessage());if(audioActive)ui("ERROR",e.toString()+"\n"+url);}
   finally{if(conn!=null)conn.disconnect();AudioTrack at=track;if(at!=null){try{at.pause();at.flush();at.release();}catch(Exception ignored){}if(track==at)track=null;}}
 }
 void readFully(InputStream in,byte[] b,int off,int len)throws IOException{while(len>0){int n=in.read(b,off,len);if(n<0)throw new EOFException("WAV header truncated");off+=n;len-=n;}}
 void swap16(byte[] b,int len){for(int i=0;i+1<len;i+=2){byte v=b[i];b[i]=b[i+1];b[i+1]=v;}}
 void stopAudio(){
   audioActive=false;
   log("STOP AUDIO");
   runOnUiThread(()->{if(player!=null){player.release();player=null;}ui("STOPPED","Waiting for TERAPHON");});
   AudioTrack at=track;if(at!=null){try{at.pause();at.flush();}catch(Exception ignored){}}
 }
 void ssdpLoop(){try{ssdp=new MulticastSocket(1900);ssdp.setReuseAddress(true);ssdp.joinGroup(InetAddress.getByName("239.255.255.250"));byte[] buf=new byte[4096];while(running){DatagramPacket p=new DatagramPacket(buf,buf.length);ssdp.receive(p);String msg=new String(p.getData(),0,p.getLength(),StandardCharsets.UTF_8);if(msg.contains("M-SEARCH")&&(msg.contains("ssdp:all")||msg.contains("MediaRenderer")||msg.contains("upnp:rootdevice"))){String st=msg.contains("MediaRenderer")?"urn:schemas-upnp-org:device:MediaRenderer:1":"upnp:rootdevice";String response="HTTP/1.1 200 OK\r\nCACHE-CONTROL: max-age=1800\r\nEXT:\r\nLOCATION: "+location()+"\r\nSERVER: Android/1.0 UPnP/1.0 TERAPHON/0.1\r\nST: "+st+"\r\nUSN: "+uuid+"::"+st+"\r\n\r\n";byte[] out=response.getBytes(StandardCharsets.UTF_8);ssdp.send(new DatagramPacket(out,out.length,p.getAddress(),p.getPort()));}}}catch(Exception e){if(running)ui("DISCOVERY ERROR",e.toString());}}
 @Override public void onDestroy(){running=false;stopAudio();try{if(http!=null)http.close();if(ssdp!=null)ssdp.close();if(lock!=null&&lock.isHeld())lock.release();}catch(Exception ignored){}pool.shutdownNow();super.onDestroy();}
}
