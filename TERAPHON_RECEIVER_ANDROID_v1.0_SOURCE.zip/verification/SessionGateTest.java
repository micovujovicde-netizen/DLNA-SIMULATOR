package com.teraphon.receiver;
public class SessionGateTest {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){SessionGate g=new SessionGate();check(g.claim("A",1000,false));check(g.busy("B",1001,false));check(!g.claim("B",1001,false));check(g.owns("A"));check(g.claim("A",2000,true));check(g.busy("B",999999,true));g.clear();check(g.claim("B",999999,false));check(!g.busy("C",1120000,false));check(g.claim("C",1120000,false));System.out.println("Session gate: 9 assertions passed");}
}
