package com.teraphon.receiver;
/** Caller serializes all operations; playback holds the lease, abandoned handshakes expire. */
final class SessionGate {
 private String owner=""; private long until;
 boolean busy(String token,long now,boolean active){if(!active&&now>=until)clear();return !owner.isEmpty()&&!owner.equals(token);}
 boolean claim(String token,long now,boolean active){if(token.isEmpty()||busy(token,now,active))return false;owner=token;until=now+120000;return true;}
 boolean owns(String token){return !token.isEmpty()&&owner.equals(token);}
 void clear(){owner="";until=0;}
}
