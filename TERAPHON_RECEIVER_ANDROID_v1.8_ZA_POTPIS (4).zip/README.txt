TERAPHON Receiver za Android 1.8
Android 8 ili noviji · Paket com.teraphon.receiver · versionCode 9

Otvori Receiver na drugom uređaju na istoj Wi-Fi mreži. Izaberi ga u
meniju Audio Output u TERAPHON-u i unesi prikazani četvorocifreni PIN.
RECEIVER NAME mijenja prikazani naziv. PIN / CHANGE PIN ponovo uparuje
Sender ako promijeniš PIN.

PAUSE prekida prijem. PLAY se vraća na trenutni prenos. STOP raskida vezu.
Zvuk ide kroz audio izlaz prijemnika, preko Bluetootha ili kabla.
Receiver ne traži pristup tuđim obavještenjima. Nastavi YouTube ili
drugi lokalni plejer ručno poslije prekida.

Ako istovremeno imaš staru aplikaciju Receiver Basic, zatvori je sa EXIT
prije pokretanja nove i upari novi Receiver. Ako si ranije instalirao
probni Receiver pod istim nazivom i Android prijavi konflikt potpisa,
ukloni samo probni Receiver. Brišu se njegov PIN i uparivanja.

Provjere izvora: sh verification/test.sh
Release build: gradle :app:assembleRelease
