package com.teraphon.receiver;
import java.util.HashMap;
import java.util.Map;
/**
 * The receiver has one active audio owner. PIN authorization is separate from a
 * recent explicit CONNECT attempt: a stale sender's automatic retry must not
 * steal the receiver back after another sender intentionally takes over.
 * All methods are called under ReceiverService's synchronization lock.
 */
final class SessionGate {
 private static final long CONNECT_WINDOW_MS=180000L;
 private final Map<String,Long> invitedUntil=new HashMap<>();
 private String owner=""; private long until;
 boolean busy(String token,long now,boolean active){if(!active&&now>=until)clear();return !owner.isEmpty()&&!owner.equals(token);}
 boolean claim(String token,long now,boolean active){if(token.isEmpty()||busy(token,now,active))return false;owner=token;until=now+120000;return true;}
 /** Call only on a valid PIN /pair or certificate-pinned, saved-token /status. */
 void arm(String token,long now){
  if(token==null||token.isEmpty())return;
  invitedUntil.entrySet().removeIf(e->e.getValue()<now);
  invitedUntil.put(token,now+CONNECT_WINDOW_MS);
 }
 boolean canStart(String token,long now){
  if(token==null||token.isEmpty())return false;
  if(owns(token))return true;
  Long deadline=invitedUntil.get(token);
  return deadline!=null&&deadline>=now;
 }
 /** Consume intentional CONNECT authorization; no silent takeover on retries. */
 boolean takeover(String token,long now){
  if(!canStart(token,now))return false;
  invitedUntil.remove(token);
  owner=token;until=now+120000;
  return true;
 }
 boolean owns(String token){return token!=null&&!token.isEmpty()&&owner.equals(token);}
 void clear(){owner="";until=0;}
 void revokeAll(){clear();invitedUntil.clear();}
}
