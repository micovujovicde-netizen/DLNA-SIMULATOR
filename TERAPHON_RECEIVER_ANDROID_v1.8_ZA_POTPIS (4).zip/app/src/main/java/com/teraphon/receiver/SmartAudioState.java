package com.teraphon.receiver;

/** Protected by ReceiverService's lock. Transport and the user's pause latch are independent. */
final class SmartAudioState {
    enum Phase { CALL_START, CALL_END, STREAM_READY }
    enum State { DISCONNECTED, LOCAL_PLAYBACK, CALL_INTERRUPTION, WAITING_FOR_STREAM, RECOVERY,
                 TERAPHON_PAUSED, TERAPHON_ACTIVE }
    static final long LEASE_MS = 25_000;
    boolean manualPause;
    boolean requested;
    boolean playing;
    boolean recovery;
    boolean negotiated;
    long sequence;
    long lastSignal;
    Phase phase = Phase.STREAM_READY;

    void open() {
        requested = playing = recovery = negotiated = false;
        sequence = lastSignal = 0;
        phase = Phase.STREAM_READY;
    }

    boolean signal(long nextSequence, Phase next, long now) {
        if (nextSequence <= sequence) return false;
        negotiated = true;
        lastSignal = now;
        sequence = nextSequence;
        if (phase != next) recovery = false;
        phase = next;
        return true;
    }

    boolean audioWanted() {
        return requested && !manualPause && phase == Phase.STREAM_READY && !recovery;
    }

    boolean leaseExpired(long now) {
        return negotiated && now - lastSignal >= LEASE_MS;
    }

    State state(boolean connected, boolean localPlaying) {
        if (!connected) return localPlaying ? State.LOCAL_PLAYBACK : State.DISCONNECTED;
        if (manualPause || !requested) return State.TERAPHON_PAUSED;
        if (phase == Phase.CALL_START) return State.CALL_INTERRUPTION;
        if (phase == Phase.CALL_END) return State.WAITING_FOR_STREAM;
        if (playing) return State.TERAPHON_ACTIVE;
        return recovery ? State.RECOVERY : State.WAITING_FOR_STREAM;
    }
}
