#!/usr/bin/env python3
"""Package the site with a verified production-signed Receiver 1.8."""
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import argparse
import json
import re
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument("base", type=Path)
parser.add_argument("apk", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--tools", type=Path, required=True, help="Android SDK Build Tools directory")
args = parser.parse_args()
if args.base.resolve() == args.output.resolve():
    parser.error("Use a separate output archive.")
cert = "66d65c0f178911456eb946b5359fbb7e5d2f7924ba199c427e14548aa52a45f5"
verification = subprocess.check_output([args.tools/"apksigner", "verify", "--print-certs", args.apk], text=True)
if f"Signer #1 certificate SHA-256 digest: {cert}" not in verification:
    parser.error("Receiver APK has an unexpected signing certificate.")
badging = subprocess.check_output([args.tools/"aapt", "dump", "badging", args.apk], text=True)
if "name='com.teraphon.receiver' versionCode='9' versionName='1.8'" not in badging or "application-debuggable" in badging:
    parser.error("Expected the Receiver 1.8 release, versionCode 9.")
manifest_dump = subprocess.check_output([args.tools/"aapt", "dump", "xmltree", args.apk, "AndroidManifest.xml"], text=True)
if any(p in manifest_dump for p in ("BIND_NOTIFICATION_LISTENER_SERVICE", "BIND_ACCESSIBILITY_SERVICE", "RECEIVE_SMS", "READ_SMS")):
    parser.error("Unexpected sensitive permissions in Receiver manifest.")

# Download, setup and upgrade guidance in all of the site's supported languages.
copy = {
    "en": (
        "Download Android Receiver 1.8",
        "Install Receiver 1.8 on a phone or tablet with Android 8 or later. If Receiver Basic is open, tap EXIT there before starting 1.8.",
        "Connect the Receiver to speakers via Bluetooth or an audio cable (AUX or a compatible adapter).",
        "Connect both devices to the same Wi-Fi. In TERAPHON, open Audio Output, choose the Receiver and enter its four-digit PIN.",
        "Use RECEIVER NAME to name a room. PLAY resumes the live stream, PAUSE pauses it, and STOP disconnects. This edition does not request access to other apps’ notifications. Resume YouTube or other local music manually after disconnecting.",
        "If Android reports a conflict with an earlier test Receiver, uninstall only that Receiver and install 1.8. Pair again with the new PIN. Keep Google Play Protect enabled.",
    ),
    "cnr": (
        "Preuzmi Android Receiver 1.8",
        "Instaliraj Receiver 1.8 na telefon ili tablet sa Androidom 8 ili novijim. Ako je otvoren stari Receiver Basic, zatvori ga dugmetom EXIT prije pokretanja verzije 1.8.",
        "Spoji Receiver sa zvučnicima preko Bluetootha ili audio kablom (AUX ili odgovarajući adapter).",
        "Poveži oba uređaja na istu Wi-Fi mrežu. U TERAPHON-u otvori Audio Output, izaberi Receiver i unesi njegov četvorocifreni PIN.",
        "Dugmetom RECEIVER NAME dodijeli naziv prostorije. PLAY se vraća na trenutni prenos, PAUSE ga pauzira, a STOP prekida vezu. Ovaj Receiver ne traži pristup obavještenjima drugih aplikacija. Poslije prekida ručno nastavi YouTube ili drugi lokalni plejer.",
        "Ako Android prijavi konflikt sa ranijim probnim Receiverom, ukloni samo taj Receiver i instaliraj 1.8. Ponovo upari uređaje novim PIN-om. Ostavi Google Play Protect uključen.",
    ),
    "de": (
        "Android Receiver 1.8 herunterladen",
        "Installiere Receiver 1.8 auf einem Gerät mit Android 8 oder neuer. Beende einen laufenden Receiver Basic zuerst mit EXIT.",
        "Verbinde den Receiver über Bluetooth oder ein Audiokabel (AUX oder passender Adapter) mit den Lautsprechern.",
        "Verbinde beide Geräte mit demselben WLAN. Wähle den Receiver in TERAPHON unter Audio Output und gib seine vierstellige PIN ein.",
        "Benenne den Raum mit RECEIVER NAME. PLAY setzt den Live-Stream fort, PAUSE pausiert ihn und STOP trennt die Verbindung. Diese Version greift nicht auf Benachrichtigungen anderer Apps zu. Setze YouTube oder andere lokale Musik manuell fort.",
        "Meldet Android einen Konflikt mit einer älteren Testversion, entferne nur diesen Receiver und installiere 1.8. Kopple ihn erneut mit der neuen PIN. Lasse Google Play Protect aktiviert.",
    ),
    "it": (
        "Scarica Android Receiver 1.8",
        "Installa Receiver 1.8 su un dispositivo con Android 8 o successivo. Prima di avviarlo, chiudi Receiver Basic con EXIT se è aperto.",
        "Collega il Receiver alle casse tramite Bluetooth o cavo audio (AUX o adattatore compatibile).",
        "Collega entrambi i dispositivi alla stessa rete Wi-Fi. In TERAPHON apri Audio Output, seleziona il Receiver e inserisci il PIN di quattro cifre.",
        "Assegna un nome alla stanza con RECEIVER NAME. PLAY riprende la diretta, PAUSE la sospende e STOP disconnette. Questa versione non accede alle notifiche delle altre app. Dopo la disconnessione, riprendi YouTube o il lettore locale manualmente.",
        "Se Android segnala un conflitto con un Receiver di prova, disinstalla solo quel Receiver e installa la versione 1.8. Ripeti l’associazione con il nuovo PIN. Lascia attivo Google Play Protect.",
    ),
    "es": (
        "Descargar Android Receiver 1.8",
        "Instala Receiver 1.8 en un dispositivo con Android 8 o posterior. Si Receiver Basic está abierto, ciérralo con EXIT antes de abrir 1.8.",
        "Conecta el Receiver a los altavoces por Bluetooth o con un cable de audio (AUX o adaptador compatible).",
        "Conecta ambos dispositivos a la misma red Wi-Fi. En TERAPHON abre Audio Output, elige el Receiver e introduce su PIN de cuatro cifras.",
        "Pon nombre a la sala con RECEIVER NAME. PLAY reanuda el directo, PAUSE lo pausa y STOP desconecta. Esta versión no accede a las notificaciones de otras apps. Reanuda YouTube u otro reproductor local manualmente al desconectar.",
        "Si Android indica un conflicto con un Receiver de prueba, desinstala solo ese Receiver e instala la versión 1.8. Vuelve a emparejarlo con el nuevo PIN. Mantén activado Google Play Protect.",
    ),
    "fr": (
        "Télécharger Android Receiver 1.8",
        "Installe Receiver 1.8 sur un appareil sous Android 8 ou version ultérieure. Si Receiver Basic est ouvert, ferme-le avec EXIT avant de lancer la version 1.8.",
        "Relie le Receiver aux enceintes par Bluetooth ou câble audio (AUX ou adaptateur compatible).",
        "Connecte les deux appareils au même Wi-Fi. Dans TERAPHON, ouvre Audio Output, sélectionne le Receiver et saisis son PIN à quatre chiffres.",
        "Nomme la pièce avec RECEIVER NAME. PLAY reprend le direct, PAUSE le met en pause et STOP déconnecte. Cette version n’accède pas aux notifications des autres applications. Après déconnexion, reprends manuellement YouTube ou le lecteur local.",
        "Si Android signale un conflit avec un ancien Receiver de test, désinstalle uniquement ce Receiver et installe la version 1.8. Associe-le à nouveau avec le nouveau PIN. Laisse Google Play Protect activé.",
    ),
}

def replace_block(source, tag, attribute, content):
    pattern = rf'(<{tag}\b[^>]*\b{attribute}[^>]*>).*?(</{tag}>)'
    result, count = re.subn(pattern, lambda m: m[1] + content + m[2], source, count=1, flags=re.S)
    if count != 1:
        raise ValueError(f"Missing site element: {attribute}")
    return result

def dump(obj):
    return json.dumps(obj, ensure_ascii=False, indent=2) + "\n"

root = "teraphon/receivers/"
download = "TERAPHON-Receiver-Android-v1.8.apk"
download_path = root + "downloads/" + download
data = args.apk.read_bytes()
cache = "rx18release"
with ZipFile(args.base) as src:
    def read(path):
        return src.read(path).decode()
    rx_route = root + "index.html"
    rx = read(rx_route)
    label, setup, output, pair, controls, upgrade = copy["en"]
    rx, count = re.subn(r'<a class="rx-button" data-rx="downloadAndroid".*?</a><a class="rx-button" data-rx="testAndroid".*?</a>', f'<a class="rx-button" data-rx="downloadAndroid" href="downloads/{download}" download>{label}</a>', rx, count=1)
    if count != 1:
        raise ValueError("Android download links changed since review.")
    rx = replace_block(rx, "h2", 'data-rx="android"', "Android Receiver 1.8")
    rx = replace_block(rx, "p", 'data-rx="androidDesc"', output)
    rx = replace_block(rx, "ol", 'data-rx-list="andSteps"', "".join(f"<li>{line}</li>" for line in [setup, pair]))
    rx = replace_block(rx, "p", 'data-rx="androidChanges"', controls)
    rx = replace_block(rx, "p", 'data-rx="andNote"', upgrade)
    rx = re.sub(r'<p data-rx="testHelp">.*?</p>', "", rx, count=1).replace("rx21aux", cache)
    rx_words = root + "i18n.json"
    i18n = json.loads(read(rx_words))
    faq_route = "assets/tera-i18n.json"
    faq = json.loads(read(faq_route))
    guide_route = "teraphon/help/guide.json"
    guide = json.loads(read(guide_route))
    for lang, (label, setup, output, pair, controls, upgrade) in copy.items():
        i18n[lang].update(android="Android Receiver 1.8", androidDesc=output, downloadAndroid=label,
                          andSteps=[setup, pair], androidChanges=controls, andNote=upgrade)
        i18n[lang].pop("testAndroid", None)
        i18n[lang].pop("testHelp", None)
        faq[lang]["faq5b"] = f"{pair} {output} {controls}"
        guide[lang]["topics"]["cast"]["body"] = f"{setup} {pair} {output} {controls} {upgrade}"
    help_route = "teraphon/help/index.html"
    help_page = replace_block(read(help_route), "p", 'data-tera="faq5b"', faq["en"]["faq5b"]).replace("rx16basic", cache)
    manifest_route = root + "manifest.json"
    manifest = json.loads(read(manifest_route))
    for field in ("assets", "testAssets"):
        manifest[field] = [item for item in manifest.get(field, []) if not item["file"].endswith(".apk")]
    manifest["assets"].append({"file": download, "bytes": len(data), "sha256": sha256(data).hexdigest(),
                               "versionName": "1.8", "versionCode": 9, "applicationId": "com.teraphon.receiver",
                               "minSdk": 26, "signingCertificateSha256": cert})
    changes = {rx_route: rx, rx_words: dump(i18n), faq_route: dump(faq), guide_route: dump(guide),
               help_route: help_page, manifest_route: dump(manifest), download_path: data,
               root+"receivers.js": read(root+"receivers.js").replace("rx21aux", cache),
               "assets/tera-site.js": read("assets/tera-site.js").replace("rx16basic", cache)}
    with ZipFile(args.output, "w", ZIP_DEFLATED) as dst:
        for name in src.namelist():
            old_apk = name.startswith(root+"downloads/") and name.endswith(".apk")
            if name not in changes and not old_apk:
                dst.writestr(name, src.read(name))
        for name, content in changes.items():
            dst.writestr(name, content)
with ZipFile(args.output) as site:
    assert site.testzip() is None
    assert site.read(download_path) == data
    assert download in site.read(rx_route).decode()
print("Receiver signed APK and localized site archive verified:", args.output)
