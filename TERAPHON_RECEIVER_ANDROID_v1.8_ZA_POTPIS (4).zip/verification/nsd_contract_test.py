from pathlib import Path
s=Path('app/src/main/java/com/teraphon/receiver/ReceiverService.java').read_text()
checks={
    'advertises NSD': 'nsd.registerService(info,NsdManager.PROTOCOL_DNS_SD,nsdRegistration)' in s,
    'advertises service type': 'info.setServiceType("_teraphon._tcp.")' in s,
    'advertises UPnP HTTP': 'info.setPort(49152)' in s,
    'advertises exact identity': 'info.setAttribute("id",id)' in s,
    'cleans up mDNS': 'nsd.unregisterService(nsdRegistration)' in s,
    'keeps SSDP': 'listeners.execute(this::ssdp)' in s,
    'keeps TLS': 'tls=ssl.getServerSocketFactory().createServerSocket(49153)' in s,
    'keeps PIN authorization': 'Incorrect PIN' in s,
    'keeps takeover': 'gate.takeover(token,now)' in s,
}
for label,passed in checks.items():
    assert passed,label
print(f'mDNS integration: {len(checks)} source checks passed')
