from pathlib import Path
base = Path(__file__).resolve().parents[1] / 'app/src/main/java/com/teraphon/receiver'
service = (base / 'ReceiverService.java').read_text()
activity = (base / 'MainActivity.java').read_text()
rename = service.split('boolean rename(', 1)[1].split('synchronized boolean changePin', 1)[0]
assert 'displayName=prefs.getString("displayName"' in service
assert 'putString("displayName",name).commit()' in rename
assert rename.index('.commit()') < rename.index('displayName=name')
assert 'tokens' not in rename and 'gate' not in rename
assert '<friendlyName>"+esc(displayName)' in service
assert 'RECEIVER NAME' in activity and '.setPositiveButton("OK",null)' in activity
print('Receiver name: validation, durable save, XML escaping and identity isolation PASS (source contract)')
