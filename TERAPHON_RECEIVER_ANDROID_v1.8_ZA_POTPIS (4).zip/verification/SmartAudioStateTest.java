package com.teraphon.receiver;

public final class SmartAudioStateTest {
    private static void check(boolean pass, String label) {
        if (!pass) throw new AssertionError(label);
    }
    public static void main(String[] args) {
        SmartAudioState state = new SmartAudioState();
        state.open();
        state.requested = true;
        check(state.audioWanted(), "legacy live request");
        state.playing = true;
        check(state.state(true,false) == SmartAudioState.State.TERAPHON_ACTIVE, "active");
        check(state.signal(5, SmartAudioState.Phase.CALL_START, 100), "new call");
        check(!state.audioWanted(), "call suspends PCM");
        check(!state.signal(4, SmartAudioState.Phase.STREAM_READY, 200), "old packet rejected");
        check(state.signal(6, SmartAudioState.Phase.CALL_END, 300), "call end");
        check(!state.audioWanted(), "wait for fresh stream");
        check(state.signal(7, SmartAudioState.Phase.CALL_START, 400), "rapid second call");
        check(!state.signal(6, SmartAudioState.Phase.CALL_END, 500), "duplicate cannot end second call");
        state.manualPause = true;
        check(state.signal(8, SmartAudioState.Phase.STREAM_READY, 600), "stream ready");
        check(!state.audioWanted(), "manual pause wins");
        check(state.leaseExpired(25_600), "lease expiration");
        state.open();
        state.requested = true;
        check(!state.audioWanted(), "manual pause survives reconnect");
        state.manualPause = false;
        check(state.audioWanted(), "explicit play");
        System.out.println("Smart Audio receiver state: 13 assertions passed");
    }
}
