#!/usr/bin/env python3
"""Static integration contract checks; does not replace an Android device test."""
from pathlib import Path
s=(Path(__file__).parents[1]/'app/src/main/java/com/teraphon/receiver/ReceiverService.java').read_text()
checks={
 'availability does not stop active audio': 'if(path.equals("/availability")&&method.equals("GET"))return ok("AVAILABLE")' in s,
 'invalid PIN is rejected before authorization': s.index('if(!MessageDigest.isEqual')<s.index('if(valid){if(path.equals("/pair"))gate.arm(token,now)'),
 'PIN pairing arms only playback, not owner mute': 'if(path.equals("/pair"))gate.arm(digest,now)' in s,
 'saved authorized connect arms playback': 'if(path.equals("/status")&&method.equals("GET")){gate.arm(token,now);return ok("READY");}' in s,
 'non-takeover commands remain locked': 'if(gate.busy(token,now,active())&&!(method.equals("POST")&&path.equals("/av/control")&&action.equals("SetAVTransportURI")))return err(423' in s,
 'valid URI checked before switching': s.index('if(!allowed(u,peer))return err(400') < s.index('if(!gate.canStart(token,now))return err(423'),
 'explicit connect required before audio interruption': s.index('if(!gate.canStart(token,now))return err(423') < s.index('boolean newOwner=!gate.owns(token);stopLocked("STOPPED",false)'),
 'preemption stops old playback without dropping Bluetooth/audio focus': 'boolean newOwner=!gate.owns(token);stopLocked("STOPPED",false);' in s,
 'ownership assigned after stopping old stream': s.index('stopLocked("STOPPED",false);') < s.index('gate.takeover(token,now)'),
 'temporary switch releases focus if no stream started': 'main.postDelayed(()->{synchronized(ReceiverService.this)' in s and 'stopLocked("STOPPED",true);lastError="Waiting for sender timed out"' in s,
 'changing PIN revokes cached authorization': 'gate.revokeAll();tokens.clear();pin=nextPin;' in s,
 'old owner STOP command requires token ownership': 'case "Stop":if(!gate.owns(token))return err(409,"No session")' in s,
}
for name, good in checks.items():
    assert good, name
print(f'Protocol contract: {len(checks)} static checks passed')
