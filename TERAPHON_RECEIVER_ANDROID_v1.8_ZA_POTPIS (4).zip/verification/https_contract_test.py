#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).parents[1]
s=(root/'app/src/main/java/com/teraphon/receiver/ReceiverService.java').read_text()
ui=(root/'app/src/main/java/com/teraphon/receiver/MainActivity.java').read_text()
checks={
 "fresh Keystore alias avoids previously unusable key": 'String alias="tera_receiver_tls_v2"' in s,
 "TLS signing allows digest none": 'KeyProperties.DIGEST_NONE,KeyProperties.DIGEST_SHA256' in s,
 "TLS server RSA decrypt allows no padding": 'KeyProperties.ENCRYPTION_PADDING_NONE,KeyProperties.ENCRYPTION_PADDING_RSA_PKCS1' in s,
 "TLS 1.2 preferred for Android compatibility": 'tlsServer.setEnabledProtocols(new String[]{"TLSv1.2"})' in s,
 "server TLS key selection": 'chooseEngineServerAlias' in s and 'chooseServerAlias(String t,Principal[] p,Socket s)' in s,
 "TLS selftest checks pinned HTTPS": 'https://127.0.0.1:49153/availability' in s and 'checkTls()' in s,
 "TLS selftest must not request PIN": 'https://127.0.0.1:49153/availability' in s,
 "TLS handshake exceptions are captured": 'startHandshake()' in s and 'tlsServerError=errorMessage(e)' in s,
 "selftest error is not overwritten by server errors": 'lastError="TLS self-test: "+errorMessage(e)' in s and 'tlsServerError=errorMessage(e)' in s,
 "status reports both errors": 'SERVER: ' in s,
 "phone status is scrollable": 'ScrollingMovementMethod()' in ui,
 "keeps PIN and token protocol": 'if(!MessageDigest.isEqual(body.getBytes' in s and 'prefs.getStringSet("tokens"' in s,
 "keeps takeover": 'gate.takeover(token,now)' in s,
 "keeps mDNS and SSDP": 'registerNsd()' in s and 'void ssdp()' in s,
 "does not print PIN": 'lastError="PIN: "+pin' not in s,
}
for name, passed in checks.items():
 print(('PASS' if passed else 'FAIL')+' '+name)
 assert passed, name
print(f'RECEIVER TLS/SECURITY: {len(checks)} source contract checks passed')
