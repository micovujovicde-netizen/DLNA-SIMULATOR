#!/usr/bin/env python3
from pathlib import Path
base=Path(__file__).parents[1]/'app/src/main/java/com/teraphon/receiver'
s=(base/'ReceiverService.java').read_text()
u=(base/'MainActivity.java').read_text()
checks={
 "change PIN button is explicit": 'PIN / CHANGE PIN' in u,
 "shows current PIN locally": 'CURRENT PIN: ' in u,
 "requires new PIN confirmation": 'p.equals(q)' in u,
 "rejects wrong length": 'p.matches("[0-9]{4}")' in u,
 "rejects old PIN": 'p.equals(svc.getPin())' in u,
 "invalid input keeps modal open": 'setPositiveButton("SAVE",null)' in u and 'dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener' in u,
 "persistence checked first": s.index('putString("pin",nextPin)') < s.index('stopLocked("STOPPED",true);\n   gate.revokeAll()'),
 "removes tokens from disk": 'putStringSet("tokens",new HashSet<>()).commit()' in s,
 "revokes authorization gate and live session": 'gate.revokeAll();tokens.clear();pin=nextPin' in s,
 "resets old PIN throttling": 'failures=0;blockedUntil=0' in s,
 "keeps same PIN no-op": 'if(pin.equals(nextPin))return true' in s,
}
for k,v in checks.items():
  print(('PASS' if v else 'FAIL')+' '+k)
  assert v,k
print(f'PIN CHANGE: {len(checks)} source contract checks passed')
