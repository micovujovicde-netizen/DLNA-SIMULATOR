package com.teraphon.receiver;
public class SessionGateTest {
 static int n;
 static void check(boolean b){n++;if(!b)throw new AssertionError("Assertion "+n);}
 public static void main(String[] args){
  SessionGate g=new SessionGate();
  // Unpaired/unauthorized senders may NOT steal audio.
  check(!g.canStart("",1000));
  check(!g.canStart("A",1000));
  check(!g.takeover("A",1000));
  // An explicit, authenticated connect arms sender A.
  g.arm("A",1000);
  check(g.canStart("A",1000));
  check(g.takeover("A",1001));
  check(g.owns("A"));
  check(g.busy("B",1002,true));
  // Stale sender B cannot preempt on reconnect/retry without fresh CONNECT.
  check(!g.takeover("B",1002));
  check(!g.owns("B"));
  // New explicit connect arms B; new playback request transfers ownership.
  g.arm("B",2000);
  check(g.busy("B",2001,true));
  check(g.canStart("B",2001));
  check(g.owns("A")); // PIN/ready did NOT interrupt audio.
  check(g.takeover("B",2002));
  check(!g.owns("A"));
  check(g.owns("B"));
  check(g.busy("A",2003,true));
  // Old sender's automatic retry cannot steal back.
  check(!g.canStart("A",2003));
  check(!g.takeover("A",2004));
  check(g.owns("B"));
  // New owner may retry without re-pairing until preempted.
  check(g.canStart("B",2005));
  check(g.takeover("B",2006));
  // Connect windows expire; old invites cannot be reused.
  g.arm("C",5000);
  check(g.canStart("C",185000));
  check(!g.canStart("C",185001));
  check(!g.takeover("C",185001));
  check(g.owns("B"));
  // A manual stop clears ownership; already-armed senders can still start.
  g.arm("D",300000);
  g.clear();
  check(!g.owns("B"));
  check(g.canStart("D",300001));
  check(g.takeover("D",300001));
  check(g.owns("D"));
  // Changing PIN revokes every pending takeover as well as current owner.
  g.arm("E",300002);
  g.revokeAll();
  check(!g.owns("D"));
  check(!g.canStart("E",300003));
  check(!g.takeover("E",300003));
  check(!g.busy("A",300004,false));
  check(!g.claim("",300004,false));
  check(g.claim("A",300004,false));
  check(!g.claim("B",300005,false));
  check(g.busy("B",300005,true));
  System.out.println("Session takeover: "+n+" assertions passed");
 }
}
